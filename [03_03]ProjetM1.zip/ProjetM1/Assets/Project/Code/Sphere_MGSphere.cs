﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Sphere_MGSphere : MonoBehaviour {
    private List<Joycon> joycons;
    private Joycon j;
    private Vector3 gyro;
    private int jc_ind = 0;
    private bool initpump;
    private float yinit;

    // Use this for initialization
    void Start()
    {
        joycons = JoyconManager.Instance.j;
        if (joycons.Count > 0)
        {
            j = joycons[jc_ind];
            gyro = j.GetGyro();
            yinit = gyro.y;
            initpump = false;
        }
        else
        {
            Debug.Log("Pas de joycons détectés.");
            yinit = -1;
        }
    }
	
	// Update is called once per frame
	void Update () {
		if(yinit == -1){
                Debug.Log("En attente de détection des joycons ...");
                Start();
        }else{
                float SphereRadius = -1;
                gyro = j.GetGyro();
                if((!initpump) && gyro.y >= yinit + 5) {
                    Debug.Log("Action de pompage initialisé.");
                    initpump = true;
                }
                if(initpump && gyro.y <= yinit - 5)
                {
                    Debug.Log("De l'air est envoyé !");
                    initpump = false;
                    gameObject.transform.localScale += new Vector3((float) 0.1, (float) 0.1, (float) 0.1);
                    SphereRadius = gameObject.transform.localScale.y;
                }
                if(SphereRadius != -1)
                {
                    if(SphereRadius >= 5)
                    {
                        Debug.Log("La sphère éclate !");
                        j.SetRumble(160, 320, 0.6f, 150);
                        Destroy(gameObject);
                        Application.Quit();
                    }
                }
        }
	}
}
